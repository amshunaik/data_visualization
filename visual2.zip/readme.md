
Name : R. Amshu Naik
Roll No : B20CS046

Data Visualization lab 2 Assignment 

Steps to run "lab2.ipynb" file is as follows:
- Copy paste the folder "Dvass" from the zip file into any folder in desktop.
- open the Vscode compiler in desktop.
- open the folder "Dvass" in it. 
- Run/Execute all the code cells .
- After executing the cells the graph of each kind will be visible of different story lines with code.
- Other than this I also attached a folder "Graph" where all the graph plot are present of this lab.