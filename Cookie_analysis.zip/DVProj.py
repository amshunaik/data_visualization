import dash
from dash import dcc
#import dash_html_components as html
from dash import html
import pandas as pd
import re
from dash import dcc, html, Input, Output
import base64
from dash import dash_table

from itertools import chain

import plotly.express as px

from wordcloud import WordCloud,STOPWORDS

app = dash.Dash(__name__)

icon_path1 = 'category.png'  
icon_path2 = 'platform.png'  
icon_path3 = 'cookie.png'  
icon_path4 = 'domain.png'  
icon_path5 = 'wildcard.png' 
icon_path6 = 'datacontroller.png'   
icon_path7 = 'userprivacy.png'  

with open(icon_path1, "rb") as img_file:
    icon_data_category = base64.b64encode(img_file.read()).decode("utf-8")
with open(icon_path2, "rb") as img_file:
    icon_data_platform = base64.b64encode(img_file.read()).decode("utf-8")
with open(icon_path3, "rb") as img_file:
    icon_data_cookie = base64.b64encode(img_file.read()).decode("utf-8")
with open(icon_path4, "rb") as img_file:
    icon_data_domain = base64.b64encode(img_file.read()).decode("utf-8")
with open(icon_path5, "rb") as img_file:
    icon_data_wildcard = base64.b64encode(img_file.read()).decode("utf-8")
with open(icon_path6, "rb") as img_file:
    icon_data_datacontroller = base64.b64encode(img_file.read()).decode("utf-8")
with open(icon_path7, "rb") as img_file:
    icon_data_userprivacy = base64.b64encode(img_file.read()).decode("utf-8")

# Read the CSV file into a DataFrame
df = pd.read_csv("open-cookie-database.csv")
df1=df.copy()


    
# #print(df['Category'].unique())                     #  'Functional' 'Analytics' 'Marketing'
# #print(df['Platform'].unique())                     # many platform
# #print(df['Cookie / Data Key name'].unique())       # ['cookiePreferences' 'td' 'CookieConsent' ... 'ftid' 'aniC' 'version']
# #print(df['Retention period'].unique())             # many
# #print(df['User Privacy & GDPR Rights Portals'].unique())
# #print(df['Wildcard match'].unique())               #  [ 0.  1. nan]
# #print(df['Wildcard match'].unique())  

# Bar chart data
bar_data1 = df['Category'].value_counts()
bar_data2=df['Wildcard match'].value_counts()

bar_data3=df['Platform'].value_counts()
bar_data4=df['Domain'].value_counts()

bar_data5=df['Data Controller'].value_counts()
# Create the bar chart
fig1 = px.bar(x=bar_data1.index, y=bar_data1.values)
fig2= px.bar(x=bar_data2.index , y=bar_data2.values)

fig3= px.bar(x=bar_data3.index , y=bar_data3.values)
fig4= px.bar(x=bar_data4.index , y=bar_data4.values)

fig5= px.bar(x=bar_data5.index , y=bar_data5.values)

pie_fig = px.pie(values=bar_data1.values, names=bar_data1.index, title='Category Distribution')

# Stacked Bar Chart
# Stacked Bar Chart (Rotated by 90 degrees)
stacked_bar_fig = px.bar(df, y='Platform', color='Category', title='Stacked Bar Chart', orientation='h', height=800)  # Set orientation to 'h' for horizontal


# ## Word clod map

# text = ' '.join(df['Description'])

# stopwords = set(STOPWORDS)
# #print(text)
# #wordcloud = WordCloud(width=800, height=400, background_color='white').generate(text)

# wordcloud = WordCloud(width = 400, height = 400,
#                 background_color ='white',
#                 stopwords = stopwords,
#                 min_font_size = 10).generate(text)

# img_data = wordcloud.to_image()
# img_data.save("wordcloud.png")
# with open("wordcloud.png", "rb") as img_file:
#     base64_img = base64.b64encode(img_file.read()).decode("utf-8")
#########################################################################################
df['Retention period'] = df['Retention period'].str.lower()
# Iterate over the 'Retention period' column
for i in range(df.shape[0]):
    value = str(df.loc[i, 'Retention period'])  # Convert value to string
    if "year" in value:
        numerical_data = re.findall(r'\d+', value)

        # Convert the numerical data to integers
        numerical_data = [int(num) for num in numerical_data]
        df.loc[i, 'Retention period'] = numerical_data[0] * 365
    
    elif "day" in value:
        numerical_data = re.findall(r'\d+', value)

        # Convert the numerical data to integers
        numerical_data = [int(num) for num in numerical_data]
        df.loc[i, 'Retention period'] = numerical_data[0] * 1
        
    elif "month" in value:
        numerical_data = re.findall(r'\d+', value)

        # Convert the numerical data to integers
        numerical_data = [int(num) for num in numerical_data]
        df.loc[i, 'Retention period'] = numerical_data[0] * 30
        
    
    elif "week" in value:
        numerical_data = re.findall(r'\d+', value)

        # Convert the numerical data to integers
        numerical_data = [int(num) for num in numerical_data]
        df.loc[i, 'Retention period'] = numerical_data[0] *7
        
    elif "hour" in value:
        numerical_data = re.findall(r'\d+', value)

        # Convert the numerical data to integers
        numerical_data = [int(num) for num in numerical_data]
        df.loc[i, 'Retention period'] = numerical_data[0] / 24
    
    elif "min" in value:
        numerical_data = re.findall(r'\d+', value)

        # Convert the numerical data to integers
        numerical_data = [int(num) for num in numerical_data]
        df.loc[i, 'Retention period'] = numerical_data[0] / 1440
        
    elif "sec" in value:
        numerical_data = re.findall(r'\d+', value)

        # Convert the numerical data to integers
        numerical_data = [int(num) for num in numerical_data]
        df.loc[i, 'Retention period'] = numerical_data[0] / 86400
    
             
    else:
        continue

commonstyle={
    'width': '75%',
    'margin-left': '40px',
    'margin-top': '55px',
    'margin-bottom': '20px',
    'font-size': '22px',
    'padding': '0px 6px',
    'font-size': '23px'
}

# datacolbar=['Category','Platform','Domain','Cookie / Data Key name']
# datacolpie=['Category','Wildcard match']
datacolbar = [
    {'label': html.Div([
        html.Img(src=f'data:image/png;base64,{icon_data_category}', style={'width': '24px', 'vertical-align': 'middle'}), 
        html.Span('Category', style={'margin-left': '5px', 'vertical-align': 'middle'})], style={'display': 'flex', 'align-items': 'center'}), 
        'value': 'Category'},
    {'label': html.Div([
        html.Img(src=f'data:image/png;base64,{icon_data_platform}', style={'width': '24px', 'vertical-align': 'middle'}), 
        html.Span('Platform', style={'margin-left': '5px', 'vertical-align': 'middle'})], style={'display': 'flex', 'align-items': 'center'}), 
        'value': 'Platform'},
    {'label': html.Div([
        html.Img(src=f'data:image/png;base64,{icon_data_cookie}', style={'width': '24px', 'vertical-align': 'middle'}), 
        html.Span('Cookie / Data Key name', style={'margin-left': '5px', 'vertical-align': 'middle'})], style={'display': 'flex', 'align-items': 'center'}), 
        'value': 'Cookie / Data Key name'},
    {'label': html.Div([
        html.Img(src=f'data:image/png;base64,{icon_data_domain}', style={'width': '24px', 'vertical-align': 'middle'}), 
        html.Span('Domain', style={'margin-left': '5px', 'vertical-align': 'middle'})], style={'display': 'flex', 'align-items': 'center'}), 
        'value': 'Domain'}
    # Add more options as needed
]
datacolpie = [
    {'label': html.Div([
        html.Img(src=f'data:image/png;base64,{icon_data_category}', style={'width': '24px', 'vertical-align': 'middle'}), 
        html.Span('Category', style={'margin-left': '5px', 'vertical-align': 'middle'})], style={'display': 'flex', 'align-items': 'center'}), 
        'value': 'Category'},
    {'label': html.Div([
        html.Img(src=f'data:image/png;base64,{icon_data_wildcard}', style={'width': '24px', 'vertical-align': 'middle'}), 
        html.Span('Wildcard match', style={'margin-left': '5px', 'vertical-align': 'middle'})], style={'display': 'flex', 'align-items': 'center'}), 
        'value': 'Wildcard match'},
    # Add more options as needed
] 

datacolstackplot_yaxis = [
    {'label': html.Div([
        html.Img(src=f'data:image/png;base64,{icon_data_platform}', style={'width': '24px', 'vertical-align': 'middle'}), 
        html.Span('Platform', style={'margin-left': '5px', 'vertical-align': 'middle'})], style={'display': 'flex', 'align-items': 'center'}), 
        'value': 'Platform'},
    {'label': html.Div([
        html.Img(src=f'data:image/png;base64,{icon_data_domain}', style={'width': '24px', 'vertical-align': 'middle'}), 
        html.Span('Domain', style={'margin-left': '5px', 'vertical-align': 'middle'})], style={'display': 'flex', 'align-items': 'center'}), 
        'value': 'Domain'},
    {'label': html.Div([
        html.Img(src=f'data:image/png;base64,{icon_data_datacontroller}', style={'width': '24px', 'vertical-align': 'middle'}), 
        html.Span('Data Controller', style={'margin-left': '5px', 'vertical-align': 'middle'})], style={'display': 'flex', 'align-items': 'center'}), 
        'value': 'Data Controller'},
    {'label': html.Div([
        html.Img(src=f'data:image/png;base64,{icon_data_userprivacy}', style={'width': '24px', 'vertical-align': 'middle'}), 
        html.Span('User Privacy & GDPR Rights Portals', style={'margin-left': '5px', 'vertical-align': 'middle'})], style={'display': 'flex', 'align-items': 'center'}), 
        'value': 'User Privacy & GDPR Rights Portals'},
    # Add more options as needed
] 

datacolstackplot_color = [
    {'label': html.Div([
        html.Img(src=f'data:image/png;base64,{icon_data_category}', style={'width': '24px', 'vertical-align': 'middle'}), 
        html.Span('Category', style={'margin-left': '5px', 'vertical-align': 'middle'})], style={'display': 'flex', 'align-items': 'center'}), 
        'value': 'Category'},
    {'label': html.Div([
        html.Img(src=f'data:image/png;base64,{icon_data_wildcard}', style={'width': '24px', 'vertical-align': 'middle'}), 
        html.Span('Wildcard match', style={'margin-left': '5px', 'vertical-align': 'middle'})], style={'display': 'flex', 'align-items': 'center'}), 
        'value': 'Wildcard match'},
    # Add more options as needed
]

###################### Tree Map

functional_df = df[df['Category'] == 'Functional']
unique_platforms1 = functional_df['Data Controller'].unique()

analytics_df = df[df['Category'] == 'Analytics']
unique_platforms2 = analytics_df['Data Controller'].unique()

marketing_df = df[df['Category'] == 'Marketing']
unique_platforms3 = marketing_df['Data Controller'].unique()

# Convert sets to lists and combine unique platforms
unique_platforms1_set = set(unique_platforms1)
unique_platforms2_set = set(unique_platforms2)
unique_platforms3_set = set(unique_platforms3)
up=[]
for x in unique_platforms1:
    up.append(x)
for x in unique_platforms2:
    up.append(x)
    
for x in unique_platforms3:
    up.append(x)
combined_unique_platforms = list(unique_platforms1_set | unique_platforms2_set | unique_platforms3_set)

val = ['Functional', 'Analytical', 'Marketing']
no1, no2, no3 = len(unique_platforms1), len(unique_platforms2), len(unique_platforms3)
hj = [val[0]] * no1 + [val[1]] * no2 + [val[2]] * no3

flattened_list = list(chain(hj))
flattened_list += ['Root'] * (len(combined_unique_platforms) - len(flattened_list))

commonstyle2={
    'align-items': 'center',
    'font-size': '19px',
    'height': '83px',
    'width' : '260px',
    'color': '#3d2b70','background': '#d9ecb3', 'border': '1px solid #418d10',
    
    'height': '70px',
    'border-radius': '19px'
}
commonstyle3={
    'width': '85%',
    'position' : 'relative',
    'margin-left': '40px',
    'margin-top': '81px',
    'margin-bottom': '73px',
    'font-size': '22px',
    'padding': '0px 6px',
    'font-size': '23px'
}
#######################################
# Define the layout of the Dash app

icon_pt = 'cook.png'  
with open(icon_pt, "rb") as img_file:
    icon_data_cat = base64.b64encode(img_file.read()).decode("utf-8")
    
app = dash.Dash(__name__, suppress_callback_exceptions=True)

app.layout = html.Div([
    html.Div([
        html.Img(src=f'data:image/png;base64,{icon_data_cat}', style={'width': '66px', 'vertical-align': 'middle','margin-left':'501px','position':'absolute'}),
    #html.Img(src='cook.png'),
    html.H1("Cookie Dashboard", style={ 'font-size': '42px','text-align': 'center','color': '#64a05f'}),
    
    ]),
    dcc.Tabs(id='tabs', style={'color': '#3d2b70','font-weight': '800','font-size': '24px'}, 
             value='tab-1', children=[
        dcc.Tab(label='Dataset', value='tab-1',style=commonstyle2),
        dcc.Tab(label='Bar Chart', value='tab-2',style=commonstyle2),
        dcc.Tab(label='Pie Chart', value='tab-3',style=commonstyle2),
        dcc.Tab(label='Word Cloud', value='tab-4',style=commonstyle2),
        dcc.Tab(label='Stacked Bar Chart', value='tab-5',style=commonstyle2),  # Add a new tab for the stacked bar chart
        dcc.Tab(label='Tree Map', value='tab-6',style=commonstyle2),
        dcc.Tab(label='Box plot & Violin plot', value='tab-7',style=commonstyle2),
        #dcc.Tab(label='Violin Plot', value='tab-8',style=commonstyle2),
        
    ]),
    
    html.Div(id='tabs-content')
], style={'position' : 'absolute','backgroundColor': '#eef7ee', 'width':'1512px', 'padding-bottom':'55px'})

comstyle3={
    'width': '71%',
    
}
@app.callback(
    Output('tabs-content', 'children'),
    [Input('tabs', 'value')]
)
def render_content(tab):
    if tab == 'tab-1':
        return html.Div([
            
            html.Div([
                html.H1("About the dataset "),
                html.H3("The dataset below represents an open cookie database, comprising attributes such as ID, Platform, Category, Cookie / Data Key name, Domain, Description, Retention period, Data Controller, User Privacy & GDPR Rights Portals, and Wildcard match. "
                        ,style={'color': 'black', 'font-size': '24px', 'font-weight': '300', }),  
                
                ],style={'width' :'1380px' , 'border': '2px solid black', 'margin': '25px 30px', 'padding': '6px 19px','background': '#e3f7dd', 'border-radius': '20px'} ),
            dash_table.DataTable(
                id='datatable',
                columns=[{'name': col, 'id': col, 'type': 'text', 'presentation': 'input'} for col in df.columns],  # Set 'presentation' to 'input' for all columns
                data=df.to_dict('records'),
                style_table={'position': 'relative','width': '1414px','overflow-x': 'scroll', 'scroll-behavior': 'smooth',
                              'border': '1px solid #0d0d14', 'margin-left': '30px'},
                #style_table={'position': 'relative','width': '1392px','overflow-x': 'scroll', 'scroll-behavior': 'smooth',
                #             'border': '1px solid #0d0d14', 'margin-left': '6px',
                #             'sticky': 'first-column'},
                style_header={
                    'fontWeight': 'bold'  # Set fontWeight to bold for all headers
                },
                style_cell_conditional=[  # Conditional styling to remove bold font from data cells
                    {
                        'if': {'column_id': c},
                        'fontWeight': 'normal'  # Set fontWeight to normal for data cells
                    } for c in df.columns
                ]
            )
        ])
    # if tab == 'tab-1':
    #     return html.Div([
            
    #         html.Div([
    #             html.H1("About the dataset "),
    #             html.H3("The dataset below represents an open cookie database, comprising attributes such as ID, Platform, Category, Cookie / Data Key name, Domain, Description, Retention period, Data Controller, User Privacy & GDPR Rights Portals, and Wildcard match. "
    #                     ,style={'color': 'black', 'font-size': '24px', 'font-weight': '300', }),  
                
                   
                
    #             ],style={'width' :'1380px' , 'border': '2px solid black', 'margin': '25px 30px', 'padding': '6px 19px','background': '#e3f7dd', 'border-radius': '20px'} ),
    #         dash_table.DataTable(
    #             id='datatable',
    #             columns=[{'name': col, 'id': col} for col in df.columns],
    #             data=df.to_dict('records'),
    #             style_table={'position': 'relative','width': '1414px','overflow-x': 'scroll', 'scroll-behavior': 'smooth',
    #                          'border': '1px solid #0d0d14', 'margin-left': '30px'}
    #         )
    #     ])
    if tab == 'tab-2':
        return html.Div([
            dcc.Dropdown(
                id='column-dropdown',
                options=datacolbar,#[{'label': col, 'value': col} for col in datacolbar],
                value='Category',  # Default value
                style={'width': '50%', 'margin-left': '40px', 'margin-top': '55px','font-size': '21px'},
            ),
            dcc.Graph(id='bar-plot', figure=fig1, style={'margin-left': '82px', 'margin-top': '44px'})
        ])
    elif tab == 'tab-3':
        return html.Div([
            dcc.Dropdown(
                id='column-dropdown-pie',
                options=datacolpie,#[{'label': col, 'value': col} for col in datacolpie],
                value='Category',  # Default value
                style={'width': '50%', 'margin-left': '40px', 'margin-top': '55px', 'font-size': '21px',}
            ),
            dcc.Graph(id='pie-plot', figure=fig2, style={'margin-top':'20px'})  # Use fig2 as default figure for pie chart
        ])
    elif tab == 'tab-4':
        return html.Div([
        html.Div([
            
            #html.Div([
            #    html.H3('Choose a Category'),
            #    html.H3('Choose a Retention period'),
            #    html.H3('Choose a wildcard match')
            #], style={'margin-left':'10px'}),
            
            html.Div([
                html.Div([
                    html.H3('Choose a Category : ',style={'margin-left': '86px', 'margin-top': '50px', 'position':'absolute', 'font-size':'22px'}),
                    dcc.Dropdown(
                        id='category-dropdown-cloud',
                        options=[{'label': category+'  category', 'value': category} for category in df['Category'].unique()],
                        value=df['Category'].unique()[0],
                        style=commonstyle3,
                        #value_style=value_style,
                        multi=False,
                        clearable=False
                    ),
                    
                ], style=comstyle3),
                
                html.Div([
                    
                html.H3('Choose a Retention period :',style={'margin-left': '86px','margin-top': '50px','position':'absolute','font-size':'22px'}),
                
                    dcc.Dropdown(
                            id='category-dropdown-retention',
                            options=[{'label': 'Retention period of less than 100 days', 'value': 100},{'label': 'Retention period of 1 year ' , 'value': 365},{'label':  'Retention period of 2 years ', 'value': 1825},
                                     {'label':  'Retention period of less than 10 years  ', 'value': 3650},{'label':  'Retention period of less than 20 years', 'value': 6570}, ],
                            value=100,
                            style=commonstyle3,
                            
                            #option_style=value_style,
                            multi=False,
                            clearable=False
                        ),
                    
                ],style=comstyle3),
                html.Div([
                    html.H3('Choose a wildcard match ; ', style={'margin-left': '86px','margin-top': '50px','position':'absolute','font-size':'22px'}),
                    dcc.Dropdown(
                            id='category-dropdown-wildcard',
                            options=[{'label': 'Cookie is not a wildcard (0)', 'value': 0},{'label': 'Cookie is a wildcard (1)' , 'value': 1}],
                            value=0,
                            style=commonstyle3,
                            #value_style=value_style,
                            multi=False,
                            clearable=False
                        ),
                    
                ],style=comstyle3)
            
                
                
                
            ], style={'display': 'flex', 'justify-content': 'center', 'gap' : '20px'})
        
        ]),
            html.Div(id='wordcloud-container', style={ 'margin-left': '513px',}),
            
        ])
    elif tab == 'tab-5':
        return html.Div([
            html.Div([ 
                dcc.Dropdown(
                    id='y-axis-dropdown',
                    options = datacolstackplot_yaxis,
                    value='Platform',  # Default value for y-axis
                    style={'width': '50%', 'margin-left': '40px', 'margin-top': '20px'}
                ),
                dcc.Dropdown(
                    id='color-dropdown',
                    options = datacolstackplot_color,
                    value='Category',  # Default value for color
                    style={'width': '50%', 'margin-left': '40px', 'margin-top': '20px'}
                ),
            ], style={    'display': 'flex','margin-bottom': '25px'}),
            dcc.Graph(id='stacked-bar-plot', figure=stacked_bar_fig),
            #dcc.RangeSlider(
            #    id='zoom-slider',
            #    min=0,
            #    max=len(df),
            #    step=1,
            #    
            #)
        ])
        
    elif tab == 'tab-6':
        return html.Div([
                    html.H1("Treemap Plot",style={'margin-left': '40px', 'margin-top': '55px'}),
                    dcc.Graph(figure=px.treemap(names=['Root', 'Functional', 'Analytical', 'Marketing'] + up,
                                                parents=[''] + ['Root', 'Root', 'Root'] + flattened_list))
                ])
    elif tab == 'tab-7':
        return html.Div([
                    
                    #html.H1(children='Box Plot and Violin Plot',style={'margin-left': '30px'}),
                    dcc.Dropdown(
                    id='category-dropdown',
                    options=[{'label': category + ' category', 'value': category} for category in df['Category'].unique()],
                    value=df['Category'].unique()[0],
                    
                    style={'width': '50%', 'margin-left': '40px', 'margin-top': '55px','font-size': '21px'},
                    #style={'width':'70%','margin-left': '30px'},
                    multi=False,
                    clearable=False
                ),
            
                # Box Plot
                html.Div([
                    html.H2('Box Plot of Retention Period '),
                    dcc.Graph(id='box-plot',style={'height': '500px', 'width': '1200px', 'margin-left': '100px'})
                ], style={'margin-left': '82px'}),
            
                # Violin Plot
                html.Div([
                    html.H2('Violin Plot of Retention Period '),
                    dcc.Graph(id='violin-plot', style={'height': '500px', 'width': '1200px', 'margin-left': '100px'})
                ], style={'margin-left': '82px','width': '1000px'})
    ])
        
   
@app.callback(
    Output('bar-plot', 'figure'),
    [Input('column-dropdown', 'value')]
)
def update_bar_plot(selected_column):
    if selected_column is None:
        # Handle the case where selected_column is None
        # For example, you can set a default column or display an error message
        raise PreventUpdate("No column selected.")
    else:
        counts = df[selected_column].value_counts()
        fig = px.bar(x=counts.index, y=counts.values, text=counts.values, title=f'Visualization of {selected_column}')
        fig.update_traces(texttemplate='%{text:.2s}', textposition='outside')  # Adjust text position and format
        fig.update_xaxes(title_text='Values')  # Add x-axis title if needed
        fig.update_yaxes(title_text='Counts')  # Add y-axis title if needed
        return fig


@app.callback(
    Output('pie-plot', 'figure'),
    [Input('column-dropdown-pie', 'value')]
)
def update_pie_plot(selected_column):
    pie_fig = px.pie(values=df[selected_column].value_counts().values, names=df[selected_column].value_counts().index, title=f'Visualization of {selected_column}')
    return pie_fig

@app.callback(
    dash.dependencies.Output('wordcloud-container', 'children'),
    [dash.dependencies.Input('category-dropdown-retention', 'value'),
     dash.dependencies.Input('category-dropdown-cloud', 'value'),
     dash.dependencies.Input('category-dropdown-wildcard', 'value'),
     ]
)
def update_wordcloud(period, category,wildcard):
    # Filter data based on selected category
    filtered_df1 = df[df['Category'] == category]
    
    print("Period:", period)
    print("Category:", category)
    print("=-------------------------------------------")
    print('vcgfvbkl.bvgcccc : ', filtered_df1)
        
    int_data = []
    lp = []
    
    for index, row in filtered_df1.iterrows():
        print("Filtered DataFrame:", len(filtered_df1))
        
        x = row['Retention period']
        print("Row Index:", index)
        print("Retention period:", x)
        
        if isinstance(x, int) or isinstance(x, float):
            if isinstance(x, float):
                row['Retention period'] = int(x) if not pd.isna(x) else None
                print("one")
            
            if x <= period:
                int_data.append(x)
                print("x:", x)
                lp.append(row)
    
    print("Filtered Data:", len(lp))
    print("Integer Data:", int_data)
    
    filtered_df2 = pd.DataFrame(lp)
    
    filtered_df = filtered_df2[filtered_df2['Wildcard match'] == wildcard]
    
    text = ' '.join(filtered_df['Description'])
    print("Test of the file:", text)
    stopwords = set(STOPWORDS)
    
    wordcloud = WordCloud(width=400, height=400, background_color='white',
                          stopwords=stopwords,
                          min_font_size=10).generate(text)
    
    img_data = wordcloud.to_image()
    img_data.save("wordcloud.png")
    
    with open("wordcloud.png", "rb") as img_file:
        base64_img = base64.b64encode(img_file.read()).decode("utf-8")

        return html.Img(src='data:image/png;base64,{}'.format(base64_img), style={'width': '676px','height': '570px','margin-left': '-69px'
})

@app.callback(
    Output('stacked-bar-plot', 'figure'),
    [Input('y-axis-dropdown', 'value'),
     Input('color-dropdown', 'value')]
)
def update_stacked_bar_plot(y_axis_column, color_column):
    stacked_bar_fig = px.bar(df, y=y_axis_column, color=color_column, title='Stacked Bar Chart', orientation='h', height=800)
    return stacked_bar_fig 


# Define callback to update the box plot
@app.callback(
    Output('box-plot', 'figure'),
    [Input('category-dropdown', 'value')]
)
def update_box_plot(category):
    filtered_df = df1[df1['Category'] == category]
    fig_box = px.box(filtered_df, y='Retention period', points='all', title='Box Plot of Retention Period by '+ category + ' category')
    return fig_box

# Define callback to update the violin plot
@app.callback(
    Output('violin-plot', 'figure'),
    [Input('category-dropdown', 'value')]
)
def update_violin_plot(category):
    filtered_df = df1[df1['Category'] == category]
    fig_violin = px.violin(filtered_df, y='Retention period', box=True, points='all', title='Violin Plot of Retention Period by '+ category+ ' category')
    return fig_violin

# Run the Dash app
if __name__ == '__main__':
    app.run_server(debug=True)